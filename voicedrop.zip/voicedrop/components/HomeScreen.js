import React from 'react';
import { Text, View, StyleSheet, Button } from 'react-native';
import t from 'tcomb-form-native';
import { createStackNavigator} from 'react-navigation';
import { Constants } from 'expo';
import { Card } from 'react-native-elements'; // 0.19.1
import Dimensions from 'Dimensions';
const Form = t.form.Form;
//import MapScreen from 'components/MapScreen';

export default class HomeScreen extends React.Component {
  
  handleSubmit = () => {
    const value = this._form.getValue().userName;
    // console.log('value:', value);
    this.props.navigation.navigate('Map', {userName: value});
  }

  static navigationOptions = {
    title: 'Voice Drop',
  };

  render() {
    const { navigate } = this.props.navigation;
    return (
      <View style={styles.container}>
        <Form
        ref={c => this._form = c}
         type={User}
         options={options}
         />
         <Button 
         title="Drop Your Voice!"
         onPress= {this.handleSubmit}
         />
      </View>
    );
  }

}

const User = t.struct({
  userName: t.String
});

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    width: Dimensions.get('window').width
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#34495e',
  },
});

const options = {
  fields: {
    userName: {
      error: 'Please enter a username!'
    }
  },
};


// export default createStackNavigator({
//   Home: HomeScreen,
//   Map: MapScreen
// });