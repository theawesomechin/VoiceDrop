import React from 'react';
import { Text, View, StyleSheet, Button } from 'react-native';
import { createStackNavigator} from 'react-navigation';
import t from 'tcomb-form-native';
const Form = t.form.Form;

class MapScreen extends React.Component {
  static navigationOptions = {
    title: 'Map',
  };

  render() {
    const { navigation} = this.props;
    return (
      <Text>
      {navigation.getParam('userName')}
      </Text>
    );
  }

}

export default MapScreen;