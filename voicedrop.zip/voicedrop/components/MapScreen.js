import React from 'react';
import { Text, View, StyleSheet, Button } from 'react-native';
import { createStackNavigator} from 'react-navigation';
import t from 'tcomb-form-native';

const Form = t.form.Form;


export default class MapScreen extends React.Component {

  render() {

    return(
      <Text>
      AYo
      </Text>
    );
    
  }

}