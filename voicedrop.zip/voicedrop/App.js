import React from 'react';
import {
  createStackNavigator,
} from 'react-navigation';
import {Button} from 'react';
import HomeScreen from './components/HomeScreen';
import MapScreen from 'components/MapScreen';

class App extends React.Component {

  render() {
    return <NavStack/>

  }

}

const NavStack = createStackNavigator({
  Home: HomeScreen,
  Map: MapScreen
},
{
  initialRouteName: 'Home',
}
);


export default App;