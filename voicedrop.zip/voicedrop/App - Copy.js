import * as React from 'react';
import { Text, View, StyleSheet, Button } from 'react-native';
import {
  createStackNavigator,
} from 'react-navigation';
import { Constants } from 'expo';
import AssetExample from './components/AssetExample';
import { Card } from 'react-native-elements'; // 0.19.1
import t from 'tcomb-form-native';
import Dimensions from 'Dimensions';
const Form = t.form.Form;


export default class App extends React.Component {

  handleSubmit = () => {
    const value = this._form.getValue();
    console.log('value:', value);
  }


  render() {
    return (
      <View style={styles.container}>
        <Text style={styles.paragraph}>
          Voice Drop
        </Text>
        <Form
        ref={c => this._form = c}
         type={User}
         options={options}
         />
         <Button 
         title="Drop Voice!"
         onPress={this.handleSubmit}
         />
      </View>
    );
  }
}

const options = {
  fields: {
    userName: {
      error: 'Please enter a username!'
    }
  },
};

const User = t.struct({
  userName: t.String
});

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    width: Dimensions.get('window').width
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
    color: '#34495e',
  },
});
